import companyLogo from "../../assets/company/companyLogo.png";
const Header = () => {
  return <h1>header</h1>;
};
export default Header;
